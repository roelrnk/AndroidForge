# Kleurlicht — Android-project

Dit is de broncode voor een eenvoudige Android-app die je telefoonscherm als gekleurde sfeerverlichting gebruikt.

## Functies
- Vijf vooraf ingestelde kleuren: rood, blauw, groen, geel en paars
- Eigen kleur samenstellen met RGB-schuifregelaars
- Helderheid instellen
- Scherm aanhouden zolang de lamp actief is
- Modus voor schermvullende weergave
- Geen internettoegang of account nodig

## Zo maak je er een installeerbare APK van
1. Installeer Android Studio op een computer: https://developer.android.com/studio
2. Pak `KleurlichtAndroid.zip` uit.
3. Open de uitgepakte map `KleurlichtAndroid` in Android Studio.
4. Laat Android Studio de Gradle-synchronisatie uitvoeren. Installeer zo nodig de Android SDK 35 via SDK Manager.
5. Kies **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Na het bouwen kun je via de melding **locate** de APK vinden. Meestal staat deze in `app/build/outputs/apk/debug/app-debug.apk`.
7. Kopieer de APK naar je Android-telefoon en open hem. Mogelijk moet je toestemming geven om apps uit die bron te installeren.

## Vereisten
- Android Studio met Android SDK 35
- JDK 17 (Android Studio levert doorgaans een geschikte runtime)
- Minimale Android-versie: Android 6.0 (API 23)

## Opmerking
Dit pakket bevat de projectbroncode, niet een vooraf gebouwde APK. De APK moet met Android Studio worden gebouwd.


## Gradle settings syntax fix
The `settings.gradle.kts` file uses Gradle's built-in repository declarations:
`google()`, `mavenCentral()`, and `gradlePluginPortal()`. It does not contain Markdown-formatted
links such as `[https://...](https://...)`. The app module is included with valid Kotlin DSL:
`include(":app")`.
