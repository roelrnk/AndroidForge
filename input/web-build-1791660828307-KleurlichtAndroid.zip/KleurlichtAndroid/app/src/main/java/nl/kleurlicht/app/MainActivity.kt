package nl.kleurlicht.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var currentColor: Int = Color.RED
    private var brightness: Int = 100
    private var fullScreen = false
    private var lightMode = false
    private var customRed = 255
    private var customGreen = 128
    private var customBlue = 220

    private val presets = listOf(
        Triple("Rood", Color.rgb(255, 45, 55), "🔴"),
        Triple("Blauw", Color.rgb(35, 105, 255), "🔵"),
        Triple("Groen", Color.rgb(35, 190, 95), "🟢"),
        Triple("Geel", Color.rgb(255, 220, 45), "🟡"),
        Triple("Paars", Color.rgb(165, 75, 235), "🟣")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 245, 248)
        window.navigationBarColor = Color.rgb(245, 245, 248)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        showMenu()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.rgb(30, 30, 36), bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
    }

    private fun button(label: String, color: Int = Color.rgb(38, 38, 46), textColor: Int = Color.WHITE, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(textColor)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            isAllCaps = false
            textSize = 16f
            setOnClickListener { action() }
        }
    }

    private fun makeRoot(background: Int = Color.rgb(247, 247, 250)): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(background)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
    }

    private fun addGap(parent: LinearLayout, height: Int = 12) {
        parent.addView(Space(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun showMenu() {
        lightMode = false
        fullScreen = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.statusBarColor = Color.rgb(247, 247, 250)
        window.navigationBarColor = Color.rgb(247, 247, 250)

        root = makeRoot()
        root.addView(text("Kleurlicht", 30f, Color.rgb(30, 30, 40), true))
        addGap(root, 5)
        root.addView(text("Maak van je scherm een sfeerlamp", 15f, Color.rgb(105, 105, 118)))
        addGap(root, 22)

        presets.forEach { (name, color, emoji) ->
            val b = button("$emoji   $name", color, if (name == "Geel") Color.rgb(55, 45, 10) else Color.WHITE) {
                currentColor = color
                showLight()
            }
            root.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)))
            addGap(root, 8)
        }

        addGap(root, 5)
        root.addView(text("Eigen kleur", 18f, Color.rgb(40, 40, 48), true))
        addGap(root, 6)
        addColorSlider("Rood", customRed) { customRed = it; updateCustomPreview() }
        addColorSlider("Groen", customGreen) { customGreen = it; updateCustomPreview() }
        addColorSlider("Blauw", customBlue) { customBlue = it; updateCustomPreview() }
        addGap(root, 8)
        root.addView(button("Gebruik mijn kleur", Color.rgb(customRed, customGreen, customBlue),
            if (luminance(customRed, customGreen, customBlue) > 0.58) Color.BLACK else Color.WHITE) {
            currentColor = Color.rgb(customRed, customGreen, customBlue)
            showLight()
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))

        root.addView(text("Tip: zet je telefoon stabiel neer en gebruik een lage helderheid als je zacht licht wilt.", 12f, Color.GRAY).apply {
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(root)
    }

    private var customPreview: Button? = null

    private fun updateCustomPreview() {
        customPreview?.apply {
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(customRed, customGreen, customBlue)))
            setTextColor(if (luminance(customRed, customGreen, customBlue) > 0.58) Color.BLACK else Color.WHITE)
        }
    }

    private fun addColorSlider(label: String, initial: Int, changed: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(text(label, 13f).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(dp(58), dp(36)))
        val seek = SeekBar(this).apply {
            max = 255
            progress = initial
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { changed(progress) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        row.addView(seek, LinearLayout.LayoutParams(0, dp(38), 1f))
        root.addView(row)
    }

    private fun luminance(r: Int, g: Int, b: Int): Double = (0.2126*r + 0.7152*g + 0.0722*b) / 255.0

    private fun showLight() {
        lightMode = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        renderLight()
    }

    private fun renderLight() {
        val color = scaleColor(currentColor, brightness / 100f)
        root = makeRoot(color)
        root.setPadding(dp(18), dp(18), dp(18), dp(18))
        root.gravity = Gravity.CENTER
        val lightText = text("Kleurlicht", 24f, readableText(color), true)
        root.addView(lightText)
        addGap(root, 18)
        root.addView(text("Helderheid  $brightness%", 15f, readableText(color)))
        val seek = SeekBar(this).apply {
            max = 100
            progress = brightness
            contentDescription = "Helderheid"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    brightness = progress.coerceAtLeast(1)
                    renderLight()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)))
        addGap(root, 12)
        root.addView(button(if (fullScreen) "Toon bediening" else "Volledig scherm", Color.argb(70, 0, 0, 0), readableText(color)) {
            fullScreen = !fullScreen
            window.decorView.systemUiVisibility = if (fullScreen) {
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            } else 0
            renderLight()
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        addGap(root, 8)
        root.addView(button("Andere kleur kiezen", Color.argb(70, 0, 0, 0), readableText(color)) {
            showMenu()
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        if (fullScreen) {
            lightText.visibility = View.GONE
            // Controls remain available so the user can exit fullscreen.
        }
        setContentView(root)
        root.setBackgroundColor(color)
        window.statusBarColor = color
        window.navigationBarColor = color
    }

    private fun scaleColor(color: Int, factor: Float): Int {
        val f = factor.coerceIn(0.01f, 1f)
        return Color.rgb(
            (Color.red(color) * f).toInt(),
            (Color.green(color) * f).toInt(),
            (Color.blue(color) * f).toInt()
        )
    }

    private fun readableText(background: Int): Int {
        val l = (0.2126 * Color.red(background) + 0.7152 * Color.green(background) + 0.0722 * Color.blue(background)) / 255.0
        return if (l > 0.58) Color.BLACK else Color.WHITE
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (lightMode) {
            showMenu()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
}
