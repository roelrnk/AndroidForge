plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "nl.kleurlicht.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.kleurlicht.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
